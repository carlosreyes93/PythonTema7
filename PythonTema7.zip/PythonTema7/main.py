import operaciones.dividor.dividor as dividir
import operaciones.multiplicador.multiplicador as multiplicar
import operaciones.restador.restador as restar
import operaciones.sumador.sumador as sumar

def main():
    print("Suma",sumar.suma(2, 3))
    print("resta",restar.restador(10, 5))
    print("multiplicar",multiplicar.multiplicador(2, 5))
    print("dividir",dividir.dividor(10, 5))

if __name__ == "__main__":
    main()


