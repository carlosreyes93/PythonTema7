def suma(a, b):
    return a + b
