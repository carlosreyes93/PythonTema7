def dividor(a, b):
    return a / b