def restador(a, b):
    return a - b