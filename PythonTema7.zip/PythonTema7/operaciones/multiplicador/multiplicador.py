def multiplicador(a, b):
    return a * b